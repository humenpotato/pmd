import React from "react";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();
  navigate("/signin");
  return (
    <div>
      <h1 className="text-center text-3xl font-bold py-8">Home Page</h1>
    </div>
  );
};

export default Home;
