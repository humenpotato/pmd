import React, { useEffect, useState } from "react";
import "datatables.net-dt/css/jquery.dataTables.css";
import $ from "jquery";
import "datatables.net";
import { CustomerListEncode } from "../Google/Sheets";
// import { UserAuth } from "../context/ExtensionAuthContext";

console.error("Dashboard 1");
const Dashboard = () => {
  console.error("Dashboard 2");
  const [Data, setData] = useState<any>([]);
  // const { user } = UserAuth();

  useEffect(() => {
    console.log("useEffect");
    // const fetchData = async () => {
    //   const apiData = CustomerList();
    //   console.log(apiData);
    //   setData(apiData);
    // };

    // fetchData();
    // chrome.identity.getAuthToken({ interactive: false }, async (token) => {
    //   if (token) {
    //     console.log("token", token);
    // if (user && user.header) {
    //   fetch(
    //     `https://sheets.googleapis.com/v4/spreadsheets/1vaBPZ8w5fzgM4mTGv7disZHMp3WQIzxDEEXKtM7e0Qg/values:batchGet?ranges=${encodeURIComponent(
    //       "CustomerList!A4:I"
    //     )}&majorDimension=ROWS`,
    //     {
    //       headers: user.header,
    //     }
    //   )
    //     .then((response: any) => response.json())
    //     .then((data) => {
    //       console.log(data);
    //       const returnData: any =
    //         data.valueRanges[0].values.map(CustomerListEncode);
    //       console.log(returnData);
    //       setData(returnData);
    //     })
    //     .catch((error) => {
    //       console.error("fetchData Error", error);
    //     });
    // }
    // });
  }, []);

  console.log(Data);

  useEffect(() => {
    $("#dashboard").DataTable({
      data: Data,
      destroy: true,
      paging: false, // autoWidth: false,
      stateSave: true,
      scrollY: "770px",
      columns: [
        { data: "DeviceID", title: "Device ID" }, //0
        { data: "CustomerName", title: "Customer Name" }, //1
        { data: "ProductName", title: "Product Name" }, //2
        { data: "WhatsappGroupName", title: "Whatsapp Group Name" }, //3
        { data: "TeamviewerID", title: "Teamviewer ID" }, //4
        {
          data: "BoringProxy",
          title: "Remote Link",
          render: function (data, type, row, meta) {
            try {
              if (data.length > 2) {
                return (
                  '<a href="https://' +
                  new URL(data).host +
                  '/" id="proxylink" class="button-25" target="_blank">Remote Link</a>'
                );
              } else {
                return "";
              }
            } catch (e) {
              console.log(e);
              console.error(data);
              return "";
            }
          },
        }, //5
        { data: "InstalledOn", title: "Installed On" }, //6
        { data: "WarrantyExpiringOn", title: "Warranty Expiring On" }, //7
        { data: "DeploymentsID", title: "Deployment Name" }, //8
      ],
      columnDefs: [
        { visible: false, targets: 6 },
        { visible: false, targets: 7 },
      ],
    });
  }, [Data]);

  return <table id="dashboard" className="display" />;
};

export default Dashboard;
