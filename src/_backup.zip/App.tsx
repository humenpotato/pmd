import { Route, Routes } from "react-router-dom";
import React, { useEffect } from "react";
import SpeedDailNavigation from "./components/SpeedDail";
// import Protected from "./components/Protected";
import Account from "./pages/Account";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Signin from "./pages/Signin";
// import { AuthContextProvider, UserAuth } from "./context/ExtensionAuthContext";
import { useNavigate } from "react-router-dom";

function App() {
  const navigate = useNavigate();
  console.error("App");
  // navigate("/signin");
  return (
    <div>
      {/* <AuthContextProvider> */}
      <SpeedDailNavigation />i
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/signin" element={<Signin />} />
        <Route
          path="/account"
          element={
            // <Protected>
            <Account />
            // </Protected>
          }
        />
      </Routes>
      {/* </AuthContextProvider> */}
    </div>
  );
}

export default App;
