import React, { ReactNode } from "react";

export interface GoogleUser {
  sub?: string | null;
  name?: string | null;
  given_name?: string | null;
  family_name?: string | null;
  picture?: string | null;
  email?: string | null;
  email_verified?: string | null;
  locale?: string | null;
  hd?: string | null;
  accessToken?: string | null;
  grantedScopes?: Array<String> | null;
  header?: HeadersInit;
}

export interface AuthContextType {
  user: GoogleUser | null;
  setUser: React.Dispatch<React.SetStateAction<GoogleUser | null>>;
  googleSignIn: () => void;
  logOut: () => void;
  children: ReactNode;
}

export interface ProtectedProps {
  children: ReactNode;
}
