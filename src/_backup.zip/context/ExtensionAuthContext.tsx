import React, { useContext, useState, useEffect } from "react";

import { AuthContextType, GoogleUser } from "./Types";

export const AuthContext = React.createContext<AuthContextType | null>(null);

export const AuthContextProvider = ({ children }: any) => {
  console.error("AuthContextProvider");

  const [user, setUser] = useState<GoogleUser | null>(null);
  // const Manifest = chrome.runtime.getManifest();
  // const oauth2ClientId = Manifest.oauth2?.client_id;
  const oauth2ClientId =
    "1122315056-j8bp9qss8a6rpd3kni8mh3vo3o0naqu5.apps.googleusercontent.com";

  useEffect(() => {
    const fetchData = async () => {
      const token = await chrome.identity.getAuthToken({
        interactive: false,
      });

      if (token) {
        fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
          .then((response) => response.json())
          .then(async (data) => {
            data.token = `Bearer ${token}`;
            data.header = {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            };
            data.grantedScopes = token.grantedScopes;
            setUser(data);
          })
          .catch((error) => {
            console.error("Error fetching user info:", error);
          });
      } else {
        chrome.identity.launchWebAuthFlow({
          url:
            "https://accounts.google.com/gsi/iframe.html?client_id=" +
            oauth2ClientId,
          interactive: true,
        });
      }
    };

    fetchData();
  }, []);

  const googleSignIn = async () => {
    try {
      const user = await chrome.identity.getAuthToken({ interactive: true });
      if (user) {
        fetch("https://www.googleapis.com/oauth2/v3/userinfo", {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
        })
          .then((response) => response.json())
          .then(async (data) => {
            data.token = `Bearer ${user.token}`;
            data.header = {
              Authorization: `Bearer ${user.token}`,
              "Content-Type": "application/json",
            };
            data.grantedScopes = user.grantedScopes;
            setUser(data);
          })
          .catch((error) => {
            console.error("Error fetching user info:", error);
          });
      } else {
        chrome.identity.launchWebAuthFlow({
          url:
            "https://accounts.google.com/gsi/iframe.html?client_id=" +
            oauth2ClientId,
          interactive: true,
        });
      }
    } catch (error) {
      console.error("Error signing in:", error);
    }
  };

  const logOut = () => {
    chrome.identity.getAuthToken({ interactive: false }, (token) => {
      if (token) {
        fetch("https://accounts.google.com/o/oauth2/revoke?token=" + token, {
          method: "POST",
        })
          .then(async () => {
            chrome.identity.removeCachedAuthToken({ token: token }, () => {
              console.error("Signed out successfully.");
            });

            chrome.identity.clearAllCachedAuthTokens(() => {
              chrome.storage.local.remove("accessToken", function () {
                alert("Signed out successfully. This window will close now.");
                window.close();
              });
            });
            localStorage.clear();
            console.error("All local Storage items are cleared.");
          })
          .catch((error) => {
            console.error("Error revoking token:", error);
          });
      }
    });
  };

  return (
    <AuthContext.Provider
      value={{ googleSignIn, logOut, user, setUser, children }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const UserAuth = () => useContext(AuthContext) as AuthContextType;
