import React, { ReactNode } from "react";

export interface GoogleUser {
  name?: string | null;
  email?: string | null;
  imageUrl?: string | null;
  givenName?: string | null;
  familyName?: string | null;
  googleId?: string | null;
  displayName?: string | null;
}

export interface AuthContextType {
  user: GoogleUser | null;
  setUser: React.Dispatch<React.SetStateAction<GoogleUser | null>>;
  googleSignIn: () => void;
  logOut: () => void;
  children: ReactNode;
}

export interface ProtectedProps {
  children: ReactNode;
}
