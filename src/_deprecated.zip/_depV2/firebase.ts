import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAu-BCMKMGoNQms9lXibFm2R9LrS0EH2H8",
  authDomain: "morphle-mech-design.firebaseapp.com",
  projectId: "morphle-mech-design",
  storageBucket: "morphle-mech-design.appspot.com",
  messagingSenderId: "1122315056",
  appId: "1:1122315056:web:8cc5bfa59ea0d38fbb36f5",
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
