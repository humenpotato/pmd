import React from "react";
import { Navigate } from "react-router-dom";
import { UserAuth } from "../context/AuthContext";
import { ProtectedProps } from "../context/Types";

const Protected: React.FC<ProtectedProps> = ({ children }) => {
  const user = UserAuth();
  console.log(user);
  if (!user) {
    return <Navigate to="/" />;
  }

  return children;
};

export default Protected;
