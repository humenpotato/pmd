// import axios from "axios";

// export const GoogleAuthToken = async (code: string) => {
//   return await axios.post("https://oauth2.googleapis.com/token", {
//     code: code,
//     client_id:
//       "1122315056-j8bp9qss8a6rpd3kni8mh3vo3o0naqu5.apps.googleusercontent.com",
//     client_secret: "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",
//     redirect_uri: "postmessage",
//     grant_type: "authorization_code",
//   });
// };

// export const GetUserInfo = async (tokens: any) => {
//   console.log(tokens);
//   axios
//     .get("https://www.googleapis.com/oauth2/v3/userinfo", {
//       headers: { Authorization: `Bearer ${tokens.data.access_token}` },
//     })
//     .then((response) => {
//       console.log(response.data);
//       return response.data;
//     })
//     .catch((error) => {
//       return error;
//     });
// };
