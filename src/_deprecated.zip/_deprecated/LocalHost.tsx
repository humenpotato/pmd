// import { useState, useEffect } from "react";
// import Button from "@mui/material/Button";
// import { GoogleAuthToken, GetUserInfo } from "./GoogleAuth";
// import { useGoogleLogin } from "@react-oauth/google";
// import {
//   BrowserRouter as Router,
//   Route,
//   Routes,
//   Navigate,
// } from "react-router-dom";
// import {Home, Dashboard} from './views/Dashboard';

// export const LocalHost = () => {
//   const [isLoggedIn, dispatchLoggedin] = useState<boolean>(false);
//   const [tokens, setToken] = useState<any>("");

//   useEffect(() => {
//     if (localStorage.tokens_auth) {
//       dispatchLoggedin(true);
//       setToken(JSON.parse(localStorage.tokens_auth));
//     }
//   }, []);

//   useEffect(() => {
//     if (isLoggedIn && tokens && tokens.data.access_token) GetUserInfo(tokens);
//   }, [isLoggedIn, tokens]);

//   const GoogleLogin = useGoogleLogin({
//     flow: "auth-code",
//     onSuccess: async (codeResponse) => {
//       console.log(codeResponse);
//       const tokens = await GoogleAuthToken(codeResponse.code);
//       setToken(tokens);
//       dispatchLoggedin(true);
//       localStorage.setItem("tokens_auth", JSON.stringify(tokens));
//     },
//     onError: (errorResponse) => console.log(errorResponse),
//   });
  
//   return isLoggedIn ? (
//     <Router>
//       <Routes>
//         <Route path="/dashboard" element={<Dashboard />} />
//       </Routes>
//       <Navigate to="/dashboard" replace />
//     </Router>
//   ) : (
//     <Button onClick={() => GoogleLogin()}>Sign in with Google</Button>
//   );
// };

// export default LocalHost;
