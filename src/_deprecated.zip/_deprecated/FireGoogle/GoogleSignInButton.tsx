import React from "react";
import { auth } from "./firebase";
import firebase from "firebase/compat/app";

const GoogleSignInButton: React.FC = () => {
  const signInWithGoogle = async () => {
    const provider = new firebase.auth.GoogleAuthProvider();
    try {
      await auth.signInWithPopup(provider).then((result) => {
        // var credential = result.credential;
        console.log(result);
      });
    } catch (error) {
      console.error(error);
    }
  };

  return <button onClick={signInWithGoogle}>Sign in with Google</button>;
};

export default GoogleSignInButton;
