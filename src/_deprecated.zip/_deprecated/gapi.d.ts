declare global {
    interface Window {
      gapi: any; // Adjust the type as needed
    }
  }
  