import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import { getAuth, signInWithPopup, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAu-BCMKMGoNQms9lXibFm2R9LrS0EH2H8",
  authDomain: "morphle-mech-design.firebaseapp.com",
  projectId: "morphle-mech-design",
  storageBucket: "morphle-mech-design.appspot.com",
  messagingSenderId: "1122315056",
  appId: "1:1122315056:web:8cc5bfa59ea0d38fbb36f5"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const provider = new firebase.auth.GoogleAuthProvider();
provider.setCustomParameters({ prompt: "select_account" });

export const signInWithGoogle = () =>
  firebase
    .auth()
    .signInWithPopup(provider)
    .then((result) => {
      var credential = result.credential;

      console.log(credential);
      console.log(result);
      // // This gives you a Google Access Token. You can use it to access the Google API.
      // var token = credential?.accessToken;
      // // The signed-in user info.
      // var user = result.user;
      // // IdP data available in result.additionalUserInfo.profile.
      // // ...
    })
    .catch((error) => {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      // The email of the user's account used.
      var email = error.email;
      // The firebase.auth.AuthCredential type that was used.
      var credential = error.credential;
      // ...
    });
