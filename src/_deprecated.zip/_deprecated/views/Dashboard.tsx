import React from 'react';

export class Dashboard extends React.Component {
    render() {
        return (
            <div>
                <h2>Dashboard</h2>
                {/* Add dashboard content */}
            </div>
        );
    }
}

export class Home extends React.Component {
    render() {
        return (
            <div>
                <h2>Home Page</h2>
            </div>
        );
    }
}
