import React from 'react';
import {Navigate} from 'react-router-dom';

const PrivateRoute: React.FC<{ element: React.ReactNode; isAuthenticated: boolean }> = (
    {element, isAuthenticated}) => {
    return isAuthenticated ? <>{element}</> : <Navigate to="/login"/>;
};

interface LoginProps {
    onLogin: () => void;
}

const LoginButton: React.FC<LoginProps> = ({onLogin}) => {
    const handleLogin = () => {
        chrome.identity.getAuthToken({interactive: true}, (token) => {
            if (!chrome.runtime.lastError) {
                console.log('Authentication token:', token);
                chrome.tabs.create({url: 'index.html'})
            } else {
                console.error(chrome.runtime.lastError);
            }
        });
    };

    return (
        <button onClick={handleLogin}>Login</button>
    );
}

interface LogoutButtonProps {
    onLogout: () => void;
}

const LogoutButton: React.FC<LogoutButtonProps> = ({onLogout}) => {
    const handleLogout = () => {
        chrome.identity.getAuthToken({interactive: false}, (token) => {
            if (token) {
                fetch('https://accounts.google.com/o/oauth2/revoke?token=' + token, {
                    method: 'POST'
                }).then(async () => {
                    chrome.identity.removeCachedAuthToken({token: token}, () => {
                        console.log('Signed out successfully.');
                    });
                    chrome.identity.clearAllCachedAuthTokens(() => {
                        chrome.storage.local.remove('accessToken', function () {
                            console.log('accessToken removed from local storage');
                        });
                    });
                    onLogout();
                    console.log('All local Storage items are cleared.');
                    window.close();
                }).catch(error => {
                    console.log('Error revoking token:', error);
                });
            }
        });

    };

    return (
        <button onClick={handleLogout}>Logout</button>
    );
};

export {LoginButton, LogoutButton, PrivateRoute};