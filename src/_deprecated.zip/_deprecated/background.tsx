// // background.js
//
// let tabCreated = false;
//
// chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//     if (message === 'login' && !tabCreated) {
//         chrome.tabs.create({url: 'index.html'}, (tab) => {
//         });
//     }
// });


// // webpack.config.js
//
// module.exports = {
//     entry: {
//         contentscript: './src/content/contentscript.tsx',
//         background: './src/background/background.tsx',
//     },
//     output: {
//         filename: '[name].js',
//         path: __dirname + '/dist',
//     },
//     // ...
// };
