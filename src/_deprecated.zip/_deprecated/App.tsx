import { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
} from "react-router-dom";
import { Home, Dashboard } from "./views/Dashboard";
import { PrivateRoute, LoginButton, LogoutButton } from "./views/AuthComponent";
import Button from "@mui/material/Button";
// import { GoogleAuthToken, GetUserInfo } from "./GoogleAuth";
// import { useGoogleLogin } from "@react-oauth/google";
import Login from "./FireBaseAuth/GoogleSignInButton";

const App = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [token, setToken] = useState<any>("");
  //   const isLocalHost = window.location.hostname === "localhost";
  // const isChromeExtension = window.location.protocol === "chrome-extension:";

  // useEffect(() => {
  //   if (isChromeExtension && !isAuthenticated) {
  //     chrome.identity.getAuthToken({ interactive: false }, (token) => {
  //       if (!chrome.runtime.lastError) {
  //         if (chrome.extension.getViews({ type: "popup" }).length > 0) {
  //           chrome.tabs.create({ url: "index.html" });
  //         } else {
  //           setIsAuthenticated(true);
  //           const tokens = { data: { access_token: token } };
  //           setToken(tokens);
  //           localStorage.setItem("tokens_auth", JSON.stringify(tokens));
  //         }
  //       } else {
  //         console.error(
  //           "chrome.runtime.lastError",
  //           JSON.stringify(chrome.runtime.lastError)
  //         );
  //       }
  //     });
  //   }
  // }, [isChromeExtension, isAuthenticated]);

  // useEffect(() => {
  //   if (localStorage.tokens_auth) {
  //     setIsAuthenticated(true);
  //     setToken(JSON.parse(localStorage.tokens_auth));
  //   }
  // }, []);

  // useEffect(() => {
  //   if (isAuthenticated && token && token.data.access_token) GetUserInfo(token);
  // }, [isAuthenticated, token]);

  const handleLogout = () => {
    setToken("");
    setIsAuthenticated(false);
    localStorage.removeItem("tokens_auth");
  };

  // const GoogleLogin = useGoogleLogin({
  //   flow: "auth-code",
  //   onSuccess: async (codeResponse) => {
  //     console.log(codeResponse);
  //     const tokens = await GoogleAuthToken(codeResponse.code);
  //     setToken(token);
  //     setIsAuthenticated(true);
  //     localStorage.setItem("tokens_auth", JSON.stringify(tokens));
  //   },
  //   onError: (errorResponse) => console.log(errorResponse),
  // });

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        {isAuthenticated ? (
          <Route
            path="/dashboard"
            element={
              <PrivateRoute
                element={<Dashboard />}
                isAuthenticated={isAuthenticated}
              />
            }
          />
        ) : null}
        <Route
          path="/login"
          element={<Login />}
          // element={
          //   isChromeExtension ? (
          //     <LoginButton onLogin={() => setIsAuthenticated(true)} />
          //   ) : (
          //     <Login />
          //     // <Button onClick={() => GoogleLogin()}>Sign in with Google</Button>
          //   )
          // }
        />
      </Routes>
      {isAuthenticated ? (
        <>
          <LogoutButton onLogout={handleLogout} />
          <Navigate to="/dashboard" replace />
        </>
      ) : (
        <Navigate to="/login" replace />
      )}
    </Router>
  );
};

export default App;
